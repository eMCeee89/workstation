# script.module.dmd-czech.common

Common python modules pack that is used by [Kodi CZ/SK](http://kodi-czsk.github.io/repository/) addons.
