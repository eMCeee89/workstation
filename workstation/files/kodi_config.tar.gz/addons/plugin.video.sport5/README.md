# plugin.video.sport5
KODI addon for Sport5.cz
